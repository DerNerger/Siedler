#ifndef RESOURCEENUM_H
#define RESOURCEENUM_H

enum ResourceEnum{
    ALL   =-1,
    SHEEP = 0,
    WOOD  = 1,
    CLAY  = 2,
    IRON  = 3,
    WHEAT = 4
};

#endif // RESOURCEENUM_H
