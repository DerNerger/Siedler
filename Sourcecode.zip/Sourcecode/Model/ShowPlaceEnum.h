#ifndef SHOWPLACEENUM_H
#define SHOWPLACEENUM_H

enum ShowPlaceEnum{
    NewYear,
    DiceRoll,
    Overview
};

#endif // SHOWPLACEENUM_H
